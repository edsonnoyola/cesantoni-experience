const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

// Ruta a las fichas técnicas - AJUSTA SEGÚN TU MAC
const FICHAS_PATH = process.env.HOME + '/Desktop/Fichas_Tecnicas_Cesantoni';

// Palabras clave para clasificar por categoría
const CATEGORIA_KEYWORDS = {
    'Mármol': ['marmol', 'marble', 'carrara', 'calacatta', 'onyx', 'travertino', 'statuario', 'pulido', 'brillante', 'caravita', 'massa', 'verttoni', 'sereni', 'veleta'],
    'Madera': ['madera', 'wood', 'roble', 'nogal', 'oak', 'walnut', 'parquet', 'tablón', 'tablon', 'blendwood', 'forestal', 'timber', 'deck'],
    'Piedra': ['piedra', 'stone', 'slate', 'pizarra', 'cantera', 'basalto', 'granito', 'concreto', 'cemento', 'volterra', 'alabama', 'bastille', 'oxford']
};

// Detectar categoría por nombre del producto
function detectarCategoria(nombre) {
    const nombreLower = nombre.toLowerCase();
    
    for (const [categoria, keywords] of Object.entries(CATEGORIA_KEYWORDS)) {
        for (const kw of keywords) {
            if (nombreLower.includes(kw)) {
                return categoria;
            }
        }
    }
    
    // Default basado en patrones comunes
    if (nombreLower.includes('15x90') || nombreLower.includes('20x120') || nombreLower.includes('23x120')) {
        return 'Madera'; // Formatos típicos de madera
    }
    if (nombreLower.includes('pulido') || nombreLower.includes('brillante') || nombreLower.includes('60x120') || nombreLower.includes('80x160')) {
        return 'Mármol'; // Formatos grandes típicos de mármol
    }
    
    return 'Piedra'; // Default
}

// Extraer formato del nombre (ej: "30x60", "45x90")
function extraerFormato(nombre) {
    const match = nombre.match(/(\d+)[xX](\d+)/);
    if (match) {
        return `${match[1]}x${match[2]} cm`;
    }
    return null;
}

// Extraer acabado del nombre
function extraerAcabado(nombre) {
    const nombreLower = nombre.toLowerCase();
    if (nombreLower.includes('pulido') || nombreLower.includes('brillante')) return 'Pulido';
    if (nombreLower.includes('mate')) return 'Mate';
    if (nombreLower.includes('satinado')) return 'Satinado';
    if (nombreLower.includes('rustico') || nombreLower.includes('rústico')) return 'Rústico';
    if (nombreLower.includes('antiderrapante') || nombreLower.includes('grip')) return 'Antiderrapante';
    if (nombreLower.includes('rect')) return 'Rectificado';
    return 'Mate'; // Default
}

// Extraer tipo del nombre
function extraerTipo(nombre, categoria) {
    const nombreLower = nombre.toLowerCase();
    
    if (nombreLower.includes('porcelan') || nombreLower.includes('gres')) return 'Porcelánico';
    if (nombreLower.includes('ceramic') || nombreLower.includes('cerámico')) return 'Cerámico';
    
    // Por categoría
    if (categoria === 'Mármol') return 'Porcelánico tipo mármol';
    if (categoria === 'Madera') return 'Porcelánico tipo madera';
    if (categoria === 'Piedra') return 'Cerámico tipo piedra';
    
    return 'Cerámico';
}

// Generar SKU único
function generarSKU(nombre) {
    return nombre
        .toUpperCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Z0-9]/g, '')
        .substring(0, 15);
}

// Generar descripción inspiradora
function generarDescripcion(nombre, categoria) {
    const descripciones = {
        'Mármol': `${nombre} captura la esencia intemporal del mármol más fino. Sus vetas naturales y acabado premium transforman cualquier espacio en un santuario de sofisticación. Una pieza que habla del buen gusto y la distinción.`,
        'Madera': `${nombre} trae la calidez y nobleza de la madera a tus espacios, con la practicidad y durabilidad de la cerámica premium. Cada tablón está diseñado para crear ambientes acogedores que invitan a quedarse.`,
        'Piedra': `Inspirado en las piedras más nobles de la naturaleza, ${nombre} aporta carácter y personalidad única a tus espacios. Su textura y tonalidades crean ambientes con alma, donde cada detalle habla de buen gusto.`
    };
    return descripciones[categoria] || descripciones['Piedra'];
}

// Generar quote
function generarQuote(categoria) {
    const quotes = {
        'Mármol': 'El lujo verdadero está en los detalles que perduran',
        'Madera': 'La elegancia natural que transforma espacios en hogares',
        'Piedra': 'Donde la naturaleza encuentra la perfección'
    };
    return quotes[categoria] || quotes['Piedra'];
}

async function importarProductos() {
    console.log('🚀 Importando productos de:', FICHAS_PATH);
    
    // Verificar que existe la carpeta
    if (!fs.existsSync(FICHAS_PATH)) {
        console.error('❌ No se encontró la carpeta:', FICHAS_PATH);
        console.log('   Asegúrate de que las fichas técnicas estén en ~/Desktop/Fichas_Tecnicas_Cesantoni/');
        process.exit(1);
    }
    
    // Leer archivos PDF
    const archivos = fs.readdirSync(FICHAS_PATH)
        .filter(f => f.toLowerCase().endsWith('.pdf') && f.startsWith('Ficha_Tecnica_'));
    
    console.log(`📁 Encontrados ${archivos.length} PDFs`);
    
    if (archivos.length === 0) {
        console.error('❌ No se encontraron archivos Ficha_Tecnica_*.pdf');
        process.exit(1);
    }
    
    // Cargar base de datos
    const SQL = await initSqlJs();
    const dbPath = './data/cesantoni.db';
    
    let db;
    if (fs.existsSync(dbPath)) {
        const buffer = fs.readFileSync(dbPath);
        db = new SQL.Database(buffer);
        console.log('✅ Base de datos cargada');
    } else {
        console.error('❌ No se encontró la base de datos en ./data/cesantoni.db');
        process.exit(1);
    }
    
    // Verificar/crear tabla products
    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sku TEXT UNIQUE,
        name TEXT,
        category TEXT,
        subcategory TEXT,
        formato TEXT,
        acabado TEXT,
        tipo TEXT,
        resistencia TEXT,
        absorcion TEXT,
        mohs TEXT,
        uso TEXT,
        piezas_caja INTEGER,
        m2_caja REAL,
        peso_caja REAL,
        imagen_url TEXT,
        video_url TEXT,
        video_status TEXT DEFAULT 'pending',
        pdf_url TEXT,
        descripcion_inspiradora TEXT,
        quote TEXT,
        landing_generated INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    
    // Limpiar productos anteriores (opcional)
    // db.run('DELETE FROM products');
    
    let importados = 0;
    let errores = 0;
    const stats = { 'Mármol': 0, 'Madera': 0, 'Piedra': 0 };
    
    for (const archivo of archivos) {
        try {
            // Extraer nombre del archivo
            // Ficha_Tecnica_Volterra.pdf -> Volterra
            let nombre = archivo
                .replace('Ficha_Tecnica_', '')
                .replace('.pdf', '')
                .replace(/_/g, ' ')
                .trim();
            
            // Limpiar nombre
            nombre = nombre
                .split(' ')
                .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
                .join(' ');
            
            const categoria = detectarCategoria(nombre);
            const formato = extraerFormato(nombre);
            const acabado = extraerAcabado(nombre);
            const tipo = extraerTipo(nombre, categoria);
            const sku = generarSKU(nombre);
            const descripcion = generarDescripcion(nombre, categoria);
            const quote = generarQuote(categoria);
            const pdfUrl = `/uploads/${archivo}`;
            
            // Insertar o actualizar
            try {
                db.run(`INSERT OR REPLACE INTO products 
                    (sku, name, category, formato, acabado, tipo, uso, pdf_url, descripcion_inspiradora, quote, active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`,
                    [sku, nombre, categoria, formato, acabado, tipo, 'Interior/Exterior', pdfUrl, descripcion, quote]
                );
                
                importados++;
                stats[categoria]++;
                console.log(`  ✅ ${nombre} [${categoria}]`);
            } catch (e) {
                // Si ya existe, actualizar
                db.run(`UPDATE products SET 
                    name = ?, category = ?, formato = ?, acabado = ?, tipo = ?, 
                    pdf_url = ?, descripcion_inspiradora = ?, quote = ?
                    WHERE sku = ?`,
                    [nombre, categoria, formato, acabado, tipo, pdfUrl, descripcion, quote, sku]
                );
                importados++;
                stats[categoria]++;
                console.log(`  🔄 ${nombre} [${categoria}] (actualizado)`);
            }
            
        } catch (e) {
            console.error(`  ❌ Error con ${archivo}:`, e.message);
            errores++;
        }
    }
    
    // Guardar base de datos
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    
    console.log('\n========================================');
    console.log('📊 RESUMEN DE IMPORTACIÓN');
    console.log('========================================');
    console.log(`✅ Productos importados: ${importados}`);
    console.log(`❌ Errores: ${errores}`);
    console.log('');
    console.log('📦 Por categoría:');
    console.log(`   🏛️  Mármol: ${stats['Mármol']}`);
    console.log(`   🌳 Madera: ${stats['Madera']}`);
    console.log(`   🪨 Piedra: ${stats['Piedra']}`);
    console.log('');
    console.log('🎉 ¡Listo! Reinicia el servidor para ver los productos.');
}

importarProductos().catch(console.error);
