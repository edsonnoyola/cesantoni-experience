const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const QRCode = require('qrcode');
const initSqlJs = require('sql.js');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Config
const CONFIG = {
    googleApiKey: 'AIzaSyC6PfKqSaaYYqBwem0k7nd331aHeVxRm8Y',
    googleProjectId: 'gen-lang-client-0810948626',
    claudeApiKey: process.env.CLAUDE_API_KEY || 'TU_CLAUDE_API_KEY_AQUI',
    baseUrl: 'http://localhost:3000'
};

let db;

// Inicializar base de datos
async function initDB() {
    const SQL = await initSqlJs();
    
    if (fs.existsSync('./data/cesantoni.db')) {
        const buffer = fs.readFileSync('./data/cesantoni.db');
        db = new SQL.Database(buffer);
        console.log('✅ Base de datos cargada');
    } else {
        db = new SQL.Database();
        createTables();
        console.log('✅ Base de datos creada');
    }
}

function createTables() {
    db.run(`CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sku TEXT UNIQUE,
        name TEXT,
        category TEXT,
        subcategory TEXT,
        formato TEXT,
        acabado TEXT,
        tipo TEXT,
        resistencia TEXT,
        absorcion TEXT,
        mohs TEXT,
        uso TEXT,
        piezas_caja INTEGER,
        m2_caja REAL,
        peso_caja REAL,
        imagen_url TEXT,
        video_url TEXT,
        video_status TEXT DEFAULT 'pending',
        pdf_url TEXT,
        descripcion_inspiradora TEXT,
        quote TEXT,
        landing_generated INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    
    db.run(`CREATE TABLE IF NOT EXISTS distributors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        slug TEXT UNIQUE,
        logo_url TEXT,
        active INTEGER DEFAULT 1
    )`);
    
    db.run(`CREATE TABLE IF NOT EXISTS stores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        distributor_id INTEGER,
        name TEXT,
        slug TEXT,
        state TEXT,
        city TEXT,
        address TEXT,
        whatsapp TEXT,
        promo_text TEXT,
        active INTEGER DEFAULT 1
    )`);
    
    db.run(`CREATE TABLE IF NOT EXISTS scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        store_id INTEGER,
        session_id TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    
    db.run(`CREATE TABLE IF NOT EXISTS whatsapp_clicks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        store_id INTEGER,
        session_id TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    
    db.run(`CREATE TABLE IF NOT EXISTS generated_landings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        filename TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`);
    
    saveDB();
}

function saveDB() {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync('./data/cesantoni.db', buffer);
}

function query(sql, params = []) {
    try {
        const result = db.exec(sql, params);
        return result[0] ? result[0].values.map(row => {
            const obj = {};
            result[0].columns.forEach((col, i) => obj[col] = row[i]);
            return obj;
        }) : [];
    } catch (e) {
        console.error('Query error:', e);
        return [];
    }
}

function run(sql, params = []) {
    try {
        db.run(sql, params);
        saveDB();
        return true;
    } catch (e) {
        console.error('Run error:', e);
        return false;
    }
}

// ============ API ENDPOINTS ============

// --- PRODUCTOS ---
app.get('/api/products', (req, res) => {
    const products = query('SELECT * FROM products WHERE active = 1 ORDER BY name');
    res.json(products);
});

app.get('/api/products/:id', (req, res) => {
    const product = query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    res.json(product[0] || null);
});

// --- DISTRIBUIDORES ---
app.get('/api/distributors', (req, res) => {
    const distributors = query('SELECT * FROM distributors WHERE active = 1 ORDER BY name');
    res.json(distributors);
});

// --- TIENDAS ---
app.get('/api/stores', (req, res) => {
    const { state, distributor } = req.query;
    let sql = `SELECT s.*, d.name as distributor_name 
               FROM stores s 
               JOIN distributors d ON s.distributor_id = d.id 
               WHERE s.active = 1`;
    if (state) sql += ` AND s.state = '${state}'`;
    if (distributor) sql += ` AND s.distributor_id = ${distributor}`;
    sql += ' ORDER BY s.state, d.name, s.name';
    res.json(query(sql));
});

app.get('/api/stores/zacatecas', (req, res) => {
    const stores = query(`
        SELECT s.*, d.name as distributor_name 
        FROM stores s 
        JOIN distributors d ON s.distributor_id = d.id 
        WHERE s.active = 1 AND s.state = 'Zacatecas'
        ORDER BY d.name, s.name
    `);
    res.json(stores);
});

// --- TRACKING ---
app.post('/api/track/scan', (req, res) => {
    const { product_sku, store_slug, session_id } = req.body;
    const product = query('SELECT id FROM products WHERE sku = ?', [product_sku])[0];
    const store = query('SELECT id FROM stores WHERE slug = ?', [store_slug])[0];
    
    if (product && store) {
        run(`INSERT INTO scans (product_id, store_id, session_id, ip_address, user_agent) 
             VALUES (?, ?, ?, ?, ?)`,
            [product.id, store.id, session_id, req.ip, req.get('User-Agent')]);
    }
    res.json({ ok: true });
});

app.post('/api/track/whatsapp', (req, res) => {
    const { product_sku, store_slug, session_id } = req.body;
    const product = query('SELECT id FROM products WHERE sku = ?', [product_sku])[0];
    const store = query('SELECT id FROM stores WHERE slug = ?', [store_slug])[0];
    
    if (product && store) {
        run(`INSERT INTO whatsapp_clicks (product_id, store_id, session_id) VALUES (?, ?, ?)`,
            [product.id, store.id, session_id]);
    }
    res.json({ ok: true });
});

// --- ANALYTICS ---
app.get('/api/analytics/overview', (req, res) => {
    const days = req.query.days || 30;
    const dateFilter = `datetime('now', '-${days} days')`;
    
    const totalScans = query(`SELECT COUNT(*) as count FROM scans WHERE created_at > ${dateFilter}`)[0]?.count || 0;
    const totalClicks = query(`SELECT COUNT(*) as count FROM whatsapp_clicks WHERE created_at > ${dateFilter}`)[0]?.count || 0;
    const totalProducts = query('SELECT COUNT(*) as count FROM products WHERE active = 1')[0]?.count || 0;
    const totalStores = query('SELECT COUNT(*) as count FROM stores WHERE active = 1')[0]?.count || 0;
    
    res.json({
        scans: totalScans,
        whatsapp_clicks: totalClicks,
        conversion_rate: totalScans > 0 ? ((totalClicks / totalScans) * 100).toFixed(1) : 0,
        products: totalProducts,
        stores: totalStores
    });
});

app.get('/api/analytics/by-state', (req, res) => {
    const data = query(`
        SELECT s.state, COUNT(sc.id) as scans
        FROM scans sc
        JOIN stores s ON sc.store_id = s.id
        GROUP BY s.state
        ORDER BY scans DESC
    `);
    res.json(data);
});

app.get('/api/analytics/by-product', (req, res) => {
    const data = query(`
        SELECT p.name, p.sku, COUNT(sc.id) as scans
        FROM scans sc
        JOIN products p ON sc.product_id = p.id
        GROUP BY p.id
        ORDER BY scans DESC
        LIMIT 20
    `);
    res.json(data);
});

// ============ GENERADOR DE LANDING PAGES ============

app.post('/api/generate-landing/:productId', async (req, res) => {
    const productId = req.params.productId;
    const product = query('SELECT * FROM products WHERE id = ?', [productId])[0];
    
    if (!product) {
        return res.status(404).json({ error: 'Producto no encontrado' });
    }
    
    try {
        // Leer template
        let template = fs.readFileSync('./public/landing-template.html', 'utf8');
        
        // Generar descripción inspiradora si no existe
        let descripcion = product.descripcion_inspiradora;
        let quote = product.quote;
        
        if (!descripcion) {
            const generatedContent = await generateInspirationContent(product);
            descripcion = generatedContent.descripcion;
            quote = generatedContent.quote;
            
            // Guardar en DB
            run(`UPDATE products SET descripcion_inspiradora = ?, quote = ? WHERE id = ?`,
                [descripcion, quote, productId]);
        }
        
        // Reemplazar placeholders
        const replacements = {
            '{{PRODUCTO_NOMBRE}}': product.name || '',
            '{{PRODUCTO_SKU}}': product.sku || '',
            '{{PRODUCTO_CATEGORIA}}': product.category || 'Piso Premium',
            '{{PRODUCTO_SUBTITULO}}': `${product.tipo || 'Cerámico'} ${product.formato || ''} ${product.acabado || ''}`.trim(),
            '{{PRODUCTO_IMAGEN}}': product.imagen_url || '/images/default-floor.jpg',
            '{{PRODUCTO_DESCRIPCION}}': product.descripcion_inspiradora || descripcion,
            '{{PRODUCTO_DESCRIPCION_INSPIRADORA}}': descripcion,
            '{{PRODUCTO_QUOTE}}': quote,
            '{{SPEC_FORMATO}}': product.formato || '-',
            '{{SPEC_TIPO}}': product.tipo || '-',
            '{{SPEC_ACABADO}}': product.acabado || '-',
            '{{SPEC_RESISTENCIA}}': product.resistencia || '-',
            '{{SPEC_ABSORCION}}': product.absorcion || '-',
            '{{SPEC_MOHS}}': product.mohs || '-',
            '{{SPEC_USO}}': product.uso || 'Interior',
            '{{SPEC_PIEZAS}}': product.piezas_caja || '-',
            '{{SPEC_M2}}': product.m2_caja || '-',
            '{{SPEC_PESO}}': product.peso_caja || '-',
            '{{VIDEO_URL}}': product.video_url || '',
            '{{CLAUDE_API_KEY}}': CONFIG.claudeApiKey,
            '{{TIENDA_NOMBRE}}': 'Tienda Cesantoni',
            '{{TIENDA_DIRECCION}}': '',
            '{{TIENDA_TELEFONO}}': '',
            '{{TIENDA_DIRECCION_ENCODED}}': ''
        };
        
        for (const [key, value] of Object.entries(replacements)) {
            template = template.split(key).join(value);
        }
        
        // Guardar archivo
        const filename = `${product.sku || product.name.toLowerCase().replace(/\s+/g, '-')}.html`;
        const filepath = `./public/landings/${filename}`;
        fs.writeFileSync(filepath, template);
        
        // Registrar en DB
        run(`INSERT INTO generated_landings (product_id, filename) VALUES (?, ?)`, [productId, filename]);
        run(`UPDATE products SET landing_generated = 1 WHERE id = ?`, [productId]);
        
        res.json({
            success: true,
            filename,
            url: `${CONFIG.baseUrl}/landings/${filename}`,
            product: product.name
        });
        
    } catch (error) {
        console.error('Error generando landing:', error);
        res.status(500).json({ error: error.message });
    }
});

// Generar contenido inspirador con Claude
async function generateInspirationContent(product) {
    // Por ahora contenido predefinido, después conectar con Claude API
    const descripciones = {
        'marmol': `Cada pieza de ${product.name} captura la esencia intemporal del mármol más fino. Sus vetas naturales cuentan historias de elegancia que transforman cualquier espacio en un santuario de sofisticación. No es solo un piso, es una declaración de tu estilo de vida.`,
        'madera': `${product.name} trae la calidez y nobleza de la madera a tus espacios, con la practicidad y durabilidad de la cerámica premium. Cada tablón está diseñado para crear ambientes acogedores que invitan a quedarse.`,
        'piedra': `Inspirado en las piedras más nobles de la naturaleza, ${product.name} aporta carácter y personalidad única a tus espacios. Su textura y tonalidades crean ambientes con alma, donde cada detalle habla de buen gusto.`,
        'default': `${product.name} representa lo mejor de Cesantoni: innovación, calidad superior y diseño excepcional. Cada pieza es el resultado de décadas de experiencia creando los pisos más exclusivos de México. Tu espacio merece esta distinción.`
    };
    
    const quotes = {
        'marmol': 'El lujo verdadero está en los detalles que perduran',
        'madera': 'La elegancia natural que transforma espacios en hogares',
        'piedra': 'Donde la naturaleza encuentra la perfección',
        'default': 'Excelencia en cada centímetro cuadrado'
    };
    
    const tipo = (product.tipo || product.category || '').toLowerCase();
    let key = 'default';
    if (tipo.includes('marmol') || tipo.includes('marble')) key = 'marmol';
    else if (tipo.includes('madera') || tipo.includes('wood')) key = 'madera';
    else if (tipo.includes('piedra') || tipo.includes('stone')) key = 'piedra';
    
    return {
        descripcion: descripciones[key],
        quote: quotes[key]
    };
}

// ============ GENERADOR DE VIDEO CON VEO 3 ============

app.post('/api/generate-video/:productId', async (req, res) => {
    const productId = req.params.productId;
    const product = query('SELECT * FROM products WHERE id = ?', [productId])[0];
    
    if (!product) {
        return res.status(404).json({ error: 'Producto no encontrado' });
    }
    
    try {
        // Marcar como procesando
        run(`UPDATE products SET video_status = 'processing' WHERE id = ?`, [productId]);
        
        // Prompt para Veo 3
        const prompt = `Cinematic slow camera movement entering a luxurious modern living room. 
The floor is covered with beautiful ${product.name} ceramic tiles (${product.tipo || 'marble style'}, ${product.acabado || 'polished finish'}).
Natural sunlight streams through large windows, highlighting the floor's texture and color.
High-end furniture, minimalist decor, warm ambient lighting.
Camera smoothly glides across the floor, showing the tile pattern and reflections.
Professional real estate video style, 4K quality, elegant and sophisticated mood.`;

        // Llamar a Veo 3 API
        const response = await fetch(
            `https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001:predictLongRunning?key=${CONFIG.googleApiKey}`,
            {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    instances: [{ prompt }],
                    parameters: {
                        aspectRatio: '16:9',
                        personGeneration: 'dont_allow',
                        durationSeconds: 8
                    }
                })
            }
        );
        
        const data = await response.json();
        
        if (data.name) {
            // Operación iniciada, guardar operation name para polling
            run(`UPDATE products SET video_status = 'generating', video_operation = ? WHERE id = ?`,
                [data.name, productId]);
            
            res.json({
                success: true,
                status: 'generating',
                operation: data.name,
                message: 'Video en proceso de generación. Puede tomar 2-5 minutos.'
            });
        } else {
            throw new Error(data.error?.message || 'Error iniciando generación');
        }
        
    } catch (error) {
        console.error('Error generando video:', error);
        run(`UPDATE products SET video_status = 'error' WHERE id = ?`, [productId]);
        res.status(500).json({ error: error.message });
    }
});

// Verificar estado del video
app.get('/api/video-status/:productId', async (req, res) => {
    const product = query('SELECT video_status, video_operation, video_url FROM products WHERE id = ?', 
        [req.params.productId])[0];
    
    if (!product) {
        return res.status(404).json({ error: 'Producto no encontrado' });
    }
    
    if (product.video_status === 'generating' && product.video_operation) {
        // Verificar con Google
        try {
            const response = await fetch(
                `https://generativelanguage.googleapis.com/v1beta/${product.video_operation}?key=${CONFIG.googleApiKey}`
            );
            const data = await response.json();
            
            if (data.done) {
                if (data.response?.generatedVideos?.[0]?.video) {
                    const videoBase64 = data.response.generatedVideos[0].video;
                    const videoBuffer = Buffer.from(videoBase64, 'base64');
                    const videoFilename = `${req.params.productId}_${Date.now()}.mp4`;
                    fs.writeFileSync(`./public/videos/${videoFilename}`, videoBuffer);
                    
                    const videoUrl = `/videos/${videoFilename}`;
                    run(`UPDATE products SET video_status = 'ready', video_url = ? WHERE id = ?`,
                        [videoUrl, req.params.productId]);
                    
                    return res.json({ status: 'ready', video_url: videoUrl });
                } else {
                    run(`UPDATE products SET video_status = 'error' WHERE id = ?`, [req.params.productId]);
                    return res.json({ status: 'error', message: 'No se generó video' });
                }
            } else {
                return res.json({ status: 'generating', progress: data.metadata?.progress || 'En proceso...' });
            }
        } catch (e) {
            return res.json({ status: product.video_status });
        }
    }
    
    res.json({ 
        status: product.video_status, 
        video_url: product.video_url 
    });
});

// ============ GENERADOR DE QR ============

app.post('/api/generate-qr', async (req, res) => {
    const { productId, storeId } = req.body;
    
    const product = query('SELECT * FROM products WHERE id = ?', [productId])[0];
    const store = query('SELECT s.*, d.name as dist_name FROM stores s JOIN distributors d ON s.distributor_id = d.id WHERE s.id = ?', [storeId])[0];
    
    if (!product || !store) {
        return res.status(404).json({ error: 'Producto o tienda no encontrado' });
    }
    
    const landingUrl = `${CONFIG.baseUrl}/landings/${product.sku || product.name.toLowerCase().replace(/\s+/g, '-')}.html`;
    const params = new URLSearchParams({
        tienda: store.name,
        dir: store.address || '',
        ciudad: store.city || '',
        estado: store.state || '',
        wa: store.whatsapp || '',
        promo: store.promo_text || ''
    });
    
    const fullUrl = `${landingUrl}?${params.toString()}`;
    
    try {
        const qrDataUrl = await QRCode.toDataURL(fullUrl, {
            width: 400,
            margin: 2,
            color: { dark: '#1a1a1a', light: '#ffffff' }
        });
        
        res.json({
            success: true,
            qr: qrDataUrl,
            url: fullUrl,
            product: product.name,
            store: store.name
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ============ INICIAR SERVIDOR ============

initDB().then(() => {
    app.listen(3000, () => {
        console.log('🚀 Cesantoni CRM corriendo en http://localhost:3000');
        console.log('📊 Dashboard: http://localhost:3000');
        console.log('🎨 Generador: http://localhost:3000/generador.html');
    });
});
