const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

// Ruta a los PDFs - AJUSTA SI ES DIFERENTE
const FICHAS_PATH = process.env.HOME + '/Desktop/Fichas_Tecnicas_Cesantoni';

// Palabras clave para clasificar categorías
const CATEGORIA_KEYWORDS = {
    'Madera': ['wood', 'madera', 'roble', 'nogal', 'oak', 'walnut', 'parquet', 'tablón', 'tablon', 'deck', 'blendwood', 'elwood', 'oakwood', 'timber', 'pine', 'pino', 'cedro', 'teca', 'bamboo', 'bambu'],
    'Mármol': ['marble', 'marmol', 'mármol', 'carrara', 'calacatta', 'onyx', 'onix', 'travertino', 'pulido', 'brillante', 'veined', 'veteado', 'statuario', 'emperador', 'crema', 'marfil', 'caravita', 'massa', 'verttoni'],
    'Piedra': ['stone', 'piedra', 'slate', 'pizarra', 'rock', 'roca', 'basalt', 'basalto', 'granito', 'granite', 'quartzite', 'cuarcita', 'limestone', 'caliza', 'concrete', 'concreto', 'cement', 'cemento', 'rustico', 'rústico', 'cotto', 'terracota']
};

// Detectar categoría por nombre
function detectarCategoria(nombre) {
    const nombreLower = nombre.toLowerCase();
    
    for (const [categoria, keywords] of Object.entries(CATEGORIA_KEYWORDS)) {
        for (const keyword of keywords) {
            if (nombreLower.includes(keyword)) {
                return categoria;
            }
        }
    }
    
    // Default basado en patrones comunes de Cesantoni
    if (nombreLower.match(/\d+x\d+/) && nombreLower.includes('90')) return 'Mármol'; // Formatos grandes suelen ser mármol
    if (nombreLower.match(/15x90|20x120|23x120/)) return 'Madera'; // Formatos alargados son madera
    
    return 'Piedra'; // Default
}

// Extraer formato del nombre si existe
function extraerFormato(nombre) {
    const match = nombre.match(/(\d+)x(\d+)/i);
    if (match) {
        return `${match[1]}x${match[2]} cm`;
    }
    return null;
}

// Limpiar nombre del producto
function limpiarNombre(filename) {
    return filename
        .replace('Ficha_Tecnica_', '')
        .replace('Ficha_tecnica_', '')
        .replace('.pdf', '')
        .replace(/_/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

// Generar SKU
function generarSKU(nombre) {
    return nombre
        .toUpperCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Z0-9]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .substring(0, 20);
}

// Detectar tipo de material
function detectarTipo(nombre, categoria) {
    const nombreLower = nombre.toLowerCase();
    
    if (nombreLower.includes('porcelan') || nombreLower.includes('gres')) return 'Porcelánico';
    if (nombreLower.includes('ceramic') || nombreLower.includes('cerám')) return 'Cerámico';
    if (nombreLower.includes('mosaico') || nombreLower.includes('mosaic')) return 'Mosaico';
    
    // Por categoría
    if (categoria === 'Mármol') return 'Porcelánico';
    if (categoria === 'Madera') return 'Porcelánico';
    return 'Cerámico';
}

// Detectar acabado
function detectarAcabado(nombre) {
    const nombreLower = nombre.toLowerCase();
    
    if (nombreLower.includes('pulido') || nombreLower.includes('polished') || nombreLower.includes('brillo')) return 'Pulido';
    if (nombreLower.includes('mate') || nombreLower.includes('matt')) return 'Mate';
    if (nombreLower.includes('satinado') || nombreLower.includes('satin')) return 'Satinado';
    if (nombreLower.includes('rustico') || nombreLower.includes('rústico') || nombreLower.includes('rustic')) return 'Rústico';
    if (nombreLower.includes('grip') || nombreLower.includes('antiderrapante')) return 'Antiderrapante';
    if (nombreLower.includes('rect') || nombreLower.includes('rectificado')) return 'Rectificado';
    
    return 'Mate'; // Default
}

async function importarProductos() {
    console.log('🚀 Importador de Productos Cesantoni\n');
    
    // Verificar que existe la carpeta
    if (!fs.existsSync(FICHAS_PATH)) {
        console.error(`❌ No se encontró la carpeta: ${FICHAS_PATH}`);
        console.log('\nAsegúrate de que los PDFs estén en ~/Desktop/Fichas_Tecnicas_Cesantoni/');
        process.exit(1);
    }
    
    // Leer archivos PDF
    const archivos = fs.readdirSync(FICHAS_PATH).filter(f => f.toLowerCase().endsWith('.pdf'));
    console.log(`📁 Encontrados ${archivos.length} archivos PDF\n`);
    
    if (archivos.length === 0) {
        console.error('❌ No se encontraron archivos PDF');
        process.exit(1);
    }
    
    // Cargar base de datos
    const SQL = await initSqlJs();
    const dbPath = './data/cesantoni.db';
    
    let db;
    if (fs.existsSync(dbPath)) {
        const buffer = fs.readFileSync(dbPath);
        db = new SQL.Database(buffer);
        console.log('✅ Base de datos cargada\n');
    } else {
        console.error('❌ No se encontró la base de datos en ./data/cesantoni.db');
        process.exit(1);
    }
    
    // Verificar/crear columna category si no existe
    try {
        db.run('ALTER TABLE products ADD COLUMN category TEXT');
    } catch (e) {
        // Ya existe, ignorar
    }
    
    // Contadores
    let importados = 0;
    let actualizados = 0;
    let errores = 0;
    
    const categoriaCount = { 'Mármol': 0, 'Madera': 0, 'Piedra': 0 };
    
    console.log('Procesando productos...\n');
    
    for (const archivo of archivos) {
        try {
            const nombre = limpiarNombre(archivo);
            const sku = generarSKU(nombre);
            const categoria = detectarCategoria(nombre);
            const formato = extraerFormato(nombre);
            const tipo = detectarTipo(nombre, categoria);
            const acabado = detectarAcabado(nombre);
            
            // Verificar si ya existe
            const existing = db.exec(`SELECT id FROM products WHERE sku = '${sku}'`);
            
            if (existing.length > 0 && existing[0].values.length > 0) {
                // Actualizar
                db.run(`UPDATE products SET 
                    name = ?, category = ?, tipo = ?, acabado = ?, formato = ?, pdf_url = ?
                    WHERE sku = ?`,
                    [nombre, categoria, tipo, acabado, formato, `/uploads/${archivo}`, sku]);
                actualizados++;
            } else {
                // Insertar nuevo
                db.run(`INSERT INTO products (sku, name, category, tipo, acabado, formato, pdf_url, uso, active, landing_generated) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 0)`,
                    [sku, nombre, categoria, tipo, acabado, formato, `/uploads/${archivo}`, 'Interior/Exterior']);
                importados++;
            }
            
            categoriaCount[categoria]++;
            
            // Mostrar progreso
            const icon = categoria === 'Mármol' ? '🏛️' : categoria === 'Madera' ? '🌳' : '🪨';
            console.log(`${icon} ${nombre} → ${categoria}`);
            
        } catch (e) {
            console.error(`❌ Error con ${archivo}: ${e.message}`);
            errores++;
        }
    }
    
    // Guardar base de datos
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    
    // Resumen
    console.log('\n' + '='.repeat(50));
    console.log('📊 RESUMEN DE IMPORTACIÓN');
    console.log('='.repeat(50));
    console.log(`✅ Nuevos productos: ${importados}`);
    console.log(`🔄 Actualizados: ${actualizados}`);
    console.log(`❌ Errores: ${errores}`);
    console.log('');
    console.log('📂 Por categoría:');
    console.log(`   🏛️ Mármol: ${categoriaCount['Mármol']}`);
    console.log(`   🌳 Madera: ${categoriaCount['Madera']}`);
    console.log(`   🪨 Piedra: ${categoriaCount['Piedra']}`);
    console.log('');
    console.log('💾 Base de datos guardada en ./data/cesantoni.db');
    console.log('\n🎉 ¡Importación completada!');
    console.log('\nAhora puedes correr: node server.js');
}

importarProductos().catch(console.error);
